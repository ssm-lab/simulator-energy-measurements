Different approaches for computing PI in parallel.
